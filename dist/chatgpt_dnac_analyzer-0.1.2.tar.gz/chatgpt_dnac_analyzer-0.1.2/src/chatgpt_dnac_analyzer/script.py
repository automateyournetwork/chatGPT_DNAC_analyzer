from .chatgpt_dnac_analyzer import cli
def run():
    cli()